"use strict";
var loadOptions = {
  useInternalCss: !0,
  locale: "en"
};
! function() {
  var a = window.q8 = window.q8 || [];
  a.invoked || (a.invoked = !0, a.load = function(t) {
    var e = document.createElement("script");
    e.type = "text/javascript", e.async = !0, e.src = "https://www.gccleads.online/registration-plugin-v1/js/app.js", e.id = "q8";
    var n = document.getElementsByTagName("script")[0];
    n.parentNode.insertBefore(e, n), a._loadOptions = t
  }, a.load(loadOptions))
}();
